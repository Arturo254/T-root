# T-root
![T-root](https://raw.githubusercontent.com/Anonymous-Zpt/Archivos/master/T-root.png) 
<a href="https://github.com/Anonymous-Zpt"><img title="Author" src="https://img.shields.io/badge/Author-Anonymous%20Zpt-svg?style=for-the-badge&logo=github"></a>
<div align="center">
<a href="#"><img title="Version" src="https://img.shields.io/badge/Version-0.2-green.svg?style=flat-square"></a>
<a href="https://github.com/Anonymous-Zpt/T-root/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/Anonymous-Zpt/T-root?color=red&style=flat-square"></a>
<a href="https://github.com/Anonymous-Zpt/T-root/network/members"><img title="Forks" src="https://img.shields.io/github/forks/Anonymous-Zpt/T-root?color=red&style=flat-square"></a>
<a href="https://github.com/Anonymous-Zpt/T-root/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/Anonymous-Zpt/T-root?label=Watchers&color=blue&style=flat-square"></a>
</div>

# ¿Qué es T-root? 

T-root es una herramienta que utiliza proot para simular los privilegios root, utilizando la palabra root como acceso directo para la activación del mismo.

# Instalación

* ` apt update && apt -y upgrade` 
* ` pkg install -y git `
* ` pkg install -y proot `
* ` termux-setup-storage `
* ` git clone https://github.com/Anonymous-Zpt/T-root `
* ` cd T-root`
* ` bash install.sh `
* ` ./start ` 

Para activar los privilegios solo se textea la palabra root y cuando el PS1($) muestre # ya estará activado el servicio. 
Para desactivarlo solo se textea exit para salir de él 

# Procedimiento YouTube

https://youtu.be/OGwhdKCeg2w

# Screenshot

 ![Imagen-Root.png](https://github.com/Anonymous-Zpt/Archivos/blob/master/Imagen-Root.png) 
