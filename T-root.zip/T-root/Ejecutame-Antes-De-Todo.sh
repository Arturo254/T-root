#!/bin/bash/

clear 

echo "HOLA ESPERA A QUE TERMINE EL PROCESO NO TARDARA NADA"

unzip T-root.zip

exit
